# Pakistan Studies – Smart Learning App

Offline Kotlin (Jetpack Compose) Android app. English + Urdu (RTL). No quiz, no internet permission.
Content: 36 topics / 564 points from `Pakistan_Studies_English_Table.docx` (`app/src/main/assets/topics.json`).

## Features
- English / اردو switch (full RTL layout)
- Search across topics, categories and points
- Filters: All, Pending, Completed, Saved
- Per-topic checklist to tick off points as you revise them
- Mark topic complete, progress bars, study streak
- Continue where you left off, Topic of the day
- Bookmarks and personal notes per topic (auto-saved)
- Read aloud (Android text-to-speech, works offline if the voice is installed)
- Share a topic outline
- Dark / light / system theme and adjustable text size

## Get the APK from GitHub
1. Create a new GitHub repo and push this folder to `main`.
2. Open the **Actions** tab, wait for **Build APK** to finish (or run it with *Run workflow*).
3. Open the run and download the artifact **PakistanStudies-debug-apk**; install `app-debug.apk` on your phone.

## Add Urdu for the points
`topics.json` has an empty `"subsUr": []` for each topic. Fill it with Urdu translations in the same order as `"subs"` (same length) and the app will show them automatically in Urdu mode.
