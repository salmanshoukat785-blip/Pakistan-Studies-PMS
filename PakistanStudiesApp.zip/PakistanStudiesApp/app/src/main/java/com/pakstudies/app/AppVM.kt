package com.pakstudies.app

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

data class Topic(
    val id: Int,
    val titleEn: String,
    val titleUr: String,
    val catEn: String,
    val catUr: String,
    val subs: List<String>,
    val subsUr: List<String>
)

fun loadTopics(ctx: Context): List<Topic> {
    val text = ctx.assets.open("topics.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
    val arr = JSONArray(text)
    return List(arr.length()) { i ->
        val o = arr.getJSONObject(i)
        fun list(key: String): List<String> {
            val a = o.optJSONArray(key) ?: return emptyList()
            return List(a.length()) { a.getString(it) }
        }
        Topic(
            id = o.getInt("id"),
            titleEn = o.getString("titleEn"),
            titleUr = o.getString("titleUr"),
            catEn = o.getString("catEn"),
            catUr = o.getString("catUr"),
            subs = list("subs"),
            subsUr = list("subsUr")
        )
    }
}

/** Short and long explanation for each point, in English and Urdu. */
class Det(val en: List<Pair<String, String>>, val ur: List<Pair<String, String>>)

fun loadDetails(ctx: Context): Map<Int, Det> {
    val text = try {
        ctx.assets.open("details.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
    } catch (e: Exception) {
        return emptyMap()
    }
    val root = JSONObject(text)
    val map = HashMap<Int, Det>()
    for (k in root.keys()) {
        val e = root.getJSONObject(k)
        fun parse(key: String): List<Pair<String, String>> {
            val a = e.optJSONArray(key) ?: return emptyList()
            return List(a.length()) {
                val p = a.getJSONArray(it)
                p.getString(0) to p.getString(1)
            }
        }
        map[k.toInt()] = Det(parse("en"), parse("ur"))
    }
    return map
}

class AppVM(app: Application) : AndroidViewModel(app) {
    private val sp = app.getSharedPreferences("pakstudies", Context.MODE_PRIVATE)

    val topics: List<Topic> = loadTopics(app)
    private val details: Map<Int, Det> = loadDetails(app)

    /** Returns (short, long) for a point, or null if no detail is written for it yet. */
    fun detail(topicId: Int, idx: Int): Pair<String, String>? {
        val d = details[topicId] ?: return null
        val list = if (isUrdu && d.ur.size > idx) d.ur else d.en
        return list.getOrNull(idx)
    }

    var lang by mutableStateOf(sp.getString("lang", "en") ?: "en")
        private set
    var theme by mutableIntStateOf(sp.getInt("theme", 0)) // 0 system, 1 light, 2 dark
        private set
    var fontScale by mutableFloatStateOf(sp.getFloat("font", 1f))
        private set
    var lastTopic by mutableIntStateOf(sp.getInt("last", 0))
        private set
    var streak by mutableIntStateOf(sp.getInt("streak", 0))
        private set
    var studyDays by mutableIntStateOf(sp.getInt("days", 0))
        private set
    var onboarded by mutableStateOf(sp.getBoolean("onb", false))
        private set

    val isUrdu get() = lang == "ur"
    fun t(en: String, ur: String) = if (isUrdu) ur else en

    private fun loadInts(key: String) =
        (sp.getStringSet(key, emptySet()) ?: emptySet()).mapNotNull { it.toIntOrNull() }

    private fun loadStrings(key: String) = (sp.getStringSet(key, emptySet()) ?: emptySet()).toList()

    val bookmarks = mutableStateListOf<Int>().apply { addAll(loadInts("bm")) }
    val done = mutableStateListOf<Int>().apply { addAll(loadInts("done")) }
    val hard = mutableStateListOf<Int>().apply { addAll(loadInts("hard")) }
    val checked = mutableStateListOf<String>().apply { addAll(loadStrings("chk")) } // "topicId:index"
    val history = mutableStateListOf<String>().apply { addAll(loadStrings("hist")) } // yyyy-MM-dd
    val notes = mutableStateMapOf<Int, String>().apply {
        for (tp in topics) {
            val n = sp.getString("note_${tp.id}", "") ?: ""
            if (n.isNotBlank()) put(tp.id, n)
        }
    }

    init {
        val today = LocalDate.now().toString()
        val last = sp.getString("lastDay", "") ?: ""
        if (last != today) {
            val yesterday = LocalDate.now().minusDays(1).toString()
            streak = if (last == yesterday) streak + 1 else 1
            studyDays += 1
            sp.edit().putString("lastDay", today).putInt("streak", streak).putInt("days", studyDays).apply()
        }
        if (!history.contains(today)) {
            history.add(today)
            sp.edit().putStringSet("hist", history.toSet()).apply()
        }
    }

    fun title(tp: Topic) = if (isUrdu) tp.titleUr else tp.titleEn
    fun category(tp: Topic) = if (isUrdu) tp.catUr else tp.catEn
    fun subtitles(tp: Topic) = if (isUrdu && tp.subsUr.size == tp.subs.size) tp.subsUr else tp.subs
    fun groupName(g: Group) = if (isUrdu) g.ur else g.en

    fun topic(id: Int) = topics.firstOrNull { it.id == id }

    fun updateLang(v: String) { lang = v; sp.edit().putString("lang", v).apply() }
    fun toggleLang() = updateLang(if (isUrdu) "en" else "ur")
    fun updateTheme(v: Int) { theme = v; sp.edit().putInt("theme", v).apply() }
    fun setFont(v: Float) { fontScale = v; sp.edit().putFloat("font", v).apply() }
    fun setLast(id: Int) { lastTopic = id; sp.edit().putInt("last", id).apply() }
    fun finishOnboarding() { onboarded = true; sp.edit().putBoolean("onb", true).apply() }

    private fun toggle(list: MutableList<Int>, id: Int, key: String) {
        if (list.contains(id)) list.remove(id) else list.add(id)
        sp.edit().putStringSet(key, list.map { it.toString() }.toSet()).apply()
    }

    fun toggleBookmark(id: Int) = toggle(bookmarks, id, "bm")
    fun toggleDone(id: Int) = toggle(done, id, "done")
    fun toggleHard(id: Int) = toggle(hard, id, "hard")

    fun isChecked(topicId: Int, idx: Int) = checked.contains("$topicId:$idx")

    fun toggleChecked(topicId: Int, idx: Int) {
        val k = "$topicId:$idx"
        if (checked.contains(k)) checked.remove(k) else checked.add(k)
        sp.edit().putStringSet("chk", checked.toSet()).apply()
    }

    fun revisedCount(tp: Topic) = tp.subs.indices.count { isChecked(tp.id, it) }

    val totalSubs get() = topics.sumOf { it.subs.size }
    val revisedSubs get() = topics.sumOf { revisedCount(it) }

    fun saveNote(id: Int, text: String) {
        if (text.isBlank()) notes.remove(id) else notes[id] = text
        sp.edit().putString("note_$id", text).apply()
    }

    fun resetProgress() {
        bookmarks.clear(); done.clear(); checked.clear(); hard.clear()
        sp.edit().remove("bm").remove("done").remove("chk").remove("hard").remove("last").apply()
        lastTopic = 0
    }

    fun topicOfTheDay(): Topic {
        val d = LocalDate.now().dayOfYear
        return topics[d % topics.size]
    }

    /** A different short point each day, with the topic it belongs to. */
    fun pointOfTheDay(): Pair<Topic, String> {
        val d = LocalDate.now().dayOfYear
        val tp = topics[(d * 5) % topics.size]
        val subs = subtitles(tp)
        return tp to subs[(d * 3) % subs.size]
    }

    /** Last 7 days (oldest first) and whether the app was opened on each day. */
    fun last7(): List<Pair<LocalDate, Boolean>> = (6 downTo 0).map { back ->
        val dt = LocalDate.now().minusDays(back.toLong())
        dt to history.contains(dt.toString())
    }

    // ---------- Study timer (focus 25 min / break 5 min) ----------
    var timerSecs by mutableIntStateOf(25 * 60)
        private set
    var timerRunning by mutableStateOf(false)
        private set
    var timerFocus by mutableStateOf(true)
        private set
    private var timerJob: Job? = null

    fun timerTotal() = if (timerFocus) 25 * 60 else 5 * 60

    fun timerToggle() {
        if (timerRunning) {
            timerJob?.cancel()
            timerRunning = false
            return
        }
        timerRunning = true
        timerJob = viewModelScope.launch {
            while (timerSecs > 0) {
                delay(1000)
                timerSecs -= 1
            }
            timerRunning = false
            timerFocus = !timerFocus
            timerSecs = timerTotal()
        }
    }

    fun timerReset() {
        timerJob?.cancel()
        timerRunning = false
        timerSecs = timerTotal()
    }

    fun timerSetMode(focus: Boolean) {
        timerJob?.cancel()
        timerRunning = false
        timerFocus = focus
        timerSecs = timerTotal()
    }
}
