package com.pakstudies.app

import androidx.compose.ui.graphics.Color

data class Group(
    val key: Int,
    val en: String,
    val ur: String,
    val emoji: String,
    val color: Color,
    val ids: List<Int>
)

val GROUPS = listOf(
    Group(1, "Ideology & Movement", "نظریہ اور تحریک", "📜", Color(0xFF0B6B3A), listOf(1, 2, 3, 13, 14, 15, 17, 22, 25)),
    Group(2, "Constitution & Rights", "آئین اور حقوق", "⚖️", Color(0xFF1565C0), listOf(10, 11, 12, 16, 18, 19, 20, 28)),
    Group(3, "Geography & Economy", "جغرافیہ اور معیشت", "🌍", Color(0xFFE65100), listOf(6, 9, 23, 29, 30)),
    Group(4, "Society & Culture", "معاشرہ اور ثقافت", "🏘️", Color(0xFF8E24AA), listOf(7, 21, 26, 27, 32)),
    Group(5, "Governance & Security", "حکمرانی اور سلامتی", "🛡️", Color(0xFFC62828), listOf(4, 8, 24, 31, 34)),
    Group(6, "Foreign Affairs & Regions", "خارجہ امور اور خطہ", "🤝", Color(0xFF00838F), listOf(5, 33, 35, 36))
)

fun groupOf(topicId: Int): Group = GROUPS.firstOrNull { topicId in it.ids } ?: GROUPS.first()
