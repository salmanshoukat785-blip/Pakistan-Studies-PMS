package com.pakstudies.app

import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onDone: () -> Unit) {
    var go by remember { mutableStateOf(false) }
    val a by animateFloatAsState(if (go) 1f else 0f, tween(900), label = "splashAlpha")
    val sc by animateFloatAsState(if (go) 1f else 0.7f, tween(900), label = "splashScale")

    LaunchedEffect(Unit) {
        go = true
        delay(1800)
        onDone()
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0B6B3A)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.graphicsLayer {
                alpha = a
                scaleX = sc
                scaleY = sc
            }
        ) {
            androidx.compose.foundation.Image(
                painter = painterResource(R.drawable.ic_launcher_foreground),
                contentDescription = null,
                modifier = Modifier.size(170.dp)
            )
            Text("Pakistan Studies", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(4.dp))
            Text("مطالعۂ پاکستان", color = Color.White, fontSize = 26.sp)
            Spacer(Modifier.height(18.dp))
            Text(
                "Learn smart. Learn offline.",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 14.sp
            )
            Text(
                "ہوشیاری سے سیکھیں، آف لائن",
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun OnboardingScreen(vm: AppVM) {
    var page by remember { mutableIntStateOf(0) }
    val last = 2

    Column(
        Modifier
            .fillMaxSize()
            .padding(24.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            TextButton(onClick = { vm.finishOnboarding() }) { Text(vm.t("Skip", "چھوڑیں")) }
        }

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = page, animationSpec = tween(350), label = "onboarding") { p ->
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    when (p) {
                        0 -> {
                            Text("🌐", fontSize = 72.sp)
                            Text(
                                "Choose your language\nزبان منتخب کریں",
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                FilterChip(
                                    selected = !vm.isUrdu,
                                    onClick = { vm.updateLang("en") },
                                    label = { Text("English", fontSize = 18.sp) }
                                )
                                FilterChip(
                                    selected = vm.isUrdu,
                                    onClick = { vm.updateLang("ur") },
                                    label = { Text("اردو", fontSize = 18.sp) }
                                )
                            }
                        }
                        1 -> {
                            Text("✅", fontSize = 72.sp)
                            Text(
                                vm.t("Study your way", "اپنے انداز میں پڑھیں"),
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                vm.t(
                                    "Tick points as you revise them, write your own notes, save favourite topics and add difficult ones to your revision list.",
                                    "پڑھتے جائیں اور نکات پر نشان لگائیں، اپنے نوٹس لکھیں، پسندیدہ مضامین محفوظ کریں اور مشکل مضامین کو ریویژن لسٹ میں ڈالیں۔"
                                ),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                        else -> {
                            Text("📴", fontSize = 72.sp)
                            Text(
                                vm.t("Fully offline", "مکمل آف لائن"),
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                            Text(
                                vm.t(
                                    "No internet needed, no ads, no account. Everything stays on your phone.",
                                    "انٹرنیٹ، اشتہارات یا اکاؤنٹ کی ضرورت نہیں۔ سب کچھ آپ کے فون میں رہتا ہے۔"
                                ),
                                textAlign = TextAlign.Center,
                                style = MaterialTheme.typography.bodyLarge
                            )
                        }
                    }
                }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            for (i in 0..last) {
                Box(
                    Modifier
                        .padding(4.dp)
                        .size(if (i == page) 12.dp else 8.dp)
                        .clip(CircleShape)
                        .background(
                            if (i == page) MaterialTheme.colorScheme.primary
                            else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        )
                )
            }
        }

        Button(
            onClick = { if (page < last) page++ else vm.finishOnboarding() },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (page < last) vm.t("Next", "آگے") else vm.t("Get started", "شروع کریں"))
        }
    }
}
