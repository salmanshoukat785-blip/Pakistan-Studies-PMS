package com.pakstudies.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    private val vm: AppVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme(vm) {
                val nav = rememberNavController()
                val entry by nav.currentBackStackEntryAsState()
                val route = entry?.destination?.route
                val tabs = listOf("home", "topics", "saved", "settings")

                Scaffold(
                    bottomBar = {
                        if (route in tabs) {
                            NavigationBar {
                                @Suppress("UNUSED_VARIABLE")
                                val items = listOf(
                                    Triple("home", vm.t("Home", "ہوم"), Icons.Filled.Home),
                                    Triple("topics", vm.t("Topics", "مضامین"), Icons.AutoMirrored.Filled.List),
                                    Triple("saved", vm.t("Saved", "محفوظ"), Icons.Filled.Favorite),
                                    Triple("settings", vm.t("Settings", "ترتیبات"), Icons.Filled.Settings)
                                )
                                items.forEach { (r, label, icon) ->
                                    NavigationBarItem(
                                        selected = route == r,
                                        onClick = {
                                            nav.navigate(r) {
                                                popUpTo("home")
                                                launchSingleTop = true
                                            }
                                        },
                                        icon = { Icon(icon, contentDescription = label) },
                                        label = { Text(label) }
                                    )
                                }
                            }
                        }
                    }
                ) { pad ->
                    NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
                        composable("home") { HomeScreen(vm) { id -> nav.navigate("topic/$id") } }
                        composable("topics") { TopicsScreen(vm) { id -> nav.navigate("topic/$id") } }
                        composable("saved") { SavedScreen(vm) { id -> nav.navigate("topic/$id") } }
                        composable("settings") { SettingsScreen(vm) }
                        composable(
                            "topic/{id}",
                            arguments = listOf(navArgument("id") { type = NavType.IntType })
                        ) { be ->
                            val id = be.arguments?.getInt("id") ?: 1
                            DetailScreen(
                                vm, id,
                                onBack = { nav.popBackStack() },
                                onOpen = { nid ->
                                    nav.navigate("topic/$nid") { popUpTo("topic/$id") { inclusive = true } }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
