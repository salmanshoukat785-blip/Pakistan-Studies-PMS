package com.pakstudies.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

class MainActivity : ComponentActivity() {
    private val vm: AppVM by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppTheme(vm) {
                var splashDone by remember { mutableStateOf(false) }
                val stage = if (!splashDone) 0 else if (!vm.onboarded) 1 else 2

                Crossfade(targetState = stage, animationSpec = tween(400), label = "stage") { s ->
                    when (s) {
                        0 -> SplashScreen { splashDone = true }
                        1 -> OnboardingScreen(vm)
                        else -> MainApp(vm)
                    }
                }
            }
        }
    }
}

@Composable
fun MainApp(vm: AppVM) {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val tabs = listOf("home", "topics", "mcq", "saved", "settings")

    Scaffold(
        bottomBar = {
            if (route in tabs) {
                NavigationBar {
                    val items = listOf(
                        Triple("home", vm.t("Home", "ہوم"), Icons.Filled.Home),
                        Triple("topics", vm.t("Topics", "مضامین"), Icons.AutoMirrored.Filled.List),
                        Triple("mcq", vm.t("MCQs", "ایم سی کیوز"), Icons.Filled.CheckCircle),
                        Triple("saved", vm.t("Saved", "محفوظ"), Icons.Filled.Favorite),
                        Triple("settings", vm.t("Settings", "ترتیبات"), Icons.Filled.Settings)
                    )
                    items.forEach { (r, label, icon) ->
                        NavigationBarItem(
                            selected = route == r,
                            onClick = {
                                nav.navigate(r) {
                                    popUpTo("home")
                                    launchSingleTop = true
                                }
                            },
                            icon = { Icon(icon, contentDescription = label) },
                            label = { Text(label) }
                        )
                    }
                }
            }
        }
    ) { pad ->
        NavHost(
            nav,
            startDestination = "home",
            modifier = Modifier.padding(pad),
            enterTransition = { fadeIn(tween(300)) },
            exitTransition = { fadeOut(tween(200)) },
            popEnterTransition = { fadeIn(tween(300)) },
            popExitTransition = { fadeOut(tween(200)) }
        ) {
            composable("home") { HomeScreen(vm) { id -> nav.navigate("topic/$id") } }
            composable("topics") { TopicsScreen(vm) { id -> nav.navigate("topic/$id") } }
            composable("saved") { SavedScreen(vm) { id -> nav.navigate("topic/$id") } }
            composable("mcq") {
                McqHomeScreen(vm) { mode, tp -> nav.navigate("mcqrun/$mode/$tp") }
            }
            composable(
                "mcqrun/{mode}/{topic}",
                arguments = listOf(
                    navArgument("mode") { type = NavType.StringType },
                    navArgument("topic") { type = NavType.IntType }
                )
            ) { be ->
                val mode = be.arguments?.getString("mode") ?: "practice"
                val tp = be.arguments?.getInt("topic") ?: 0
                McqRunScreen(vm, mode, tp) { nav.popBackStack() }
            }
            composable("settings") { SettingsScreen(vm) }
            composable(
                "topic/{id}",
                arguments = listOf(navArgument("id") { type = NavType.IntType })
            ) { be ->
                val id = be.arguments?.getInt("id") ?: 1
                DetailScreen(
                    vm, id,
                    onBack = { nav.popBackStack() },
                    onPractice = { nav.navigate("mcqrun/practice/$id") },
                    onOpen = { nid ->
                        nav.navigate("topic/$nid") { popUpTo("topic/$id") { inclusive = true } }
                    }
                )
            }
        }
    }
}
