package com.pakstudies.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private val GoodColor = Color(0xFF2E7D32)
private val BadColor = Color(0xFFC62828)

private fun Mcq.question(vm: AppVM) = if (vm.isUrdu) qUr else qEn
private fun Mcq.options(vm: AppVM) = if (vm.isUrdu && oUr.size == oEn.size) oUr else oEn
private fun Mcq.explanation(vm: AppVM) = if (vm.isUrdu) eUr else eEn

private fun letters(vm: AppVM) =
    if (vm.isUrdu) listOf("الف", "ب", "ج", "د") else listOf("A", "B", "C", "D")

// ---------- MCQs home (tab) ----------

@Composable
fun McqHomeScreen(vm: AppVM, onRun: (String, Int) -> Unit) {
    val total = vm.mcqs.size
    val answered = vm.mcqRight.size + vm.mcqWrong.size

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            vm.t("MCQs bank", "ایم سی کیوز بینک"),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.primary
        )

        if (total == 0) {
            Text(vm.t("MCQs will appear here soon.", "ایم سی کیوز جلد یہاں آئیں گے۔"))
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        vm.t("Practised $answered of $total", "مشق کیے گئے $answered از $total"),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    LinearProgressIndicator(
                        progress = { if (total == 0) 0f else answered / total.toFloat() },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text("✅ " + vm.t("Correct: ${vm.mcqRight.size}", "درست: ${vm.mcqRight.size}"))
                    Text("🔁 " + vm.t("To revise: ${vm.mcqWrong.size}", "دوبارہ دیکھنے والے: ${vm.mcqWrong.size}"))
                    Text("❤ " + vm.t("Saved: ${vm.mcqSaved.size}", "محفوظ: ${vm.mcqSaved.size}"))
                }
            }

            Button(onClick = { onRun("practice", 0) }, modifier = Modifier.fillMaxWidth()) {
                Text(vm.t("Practice all (random order)", "تمام کی مشق (بے ترتیب)"))
            }
            OutlinedButton(
                onClick = { onRun("wrong", 0) },
                enabled = vm.mcqWrong.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(vm.t("Revise my wrong answers (${vm.mcqWrong.size})", "غلط جوابات دوبارہ دیکھیں (${vm.mcqWrong.size})"))
            }
            OutlinedButton(
                onClick = { onRun("saved", 0) },
                enabled = vm.mcqSaved.isNotEmpty(),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(vm.t("Saved MCQs (${vm.mcqSaved.size})", "محفوظ ایم سی کیوز (${vm.mcqSaved.size})"))
            }
            OutlinedButton(onClick = { onRun("browse", 0) }, modifier = Modifier.fillMaxWidth()) {
                Text(vm.t("Read all with answers", "جوابات کے ساتھ سب پڑھیں"))
            }

            Text(
                vm.t("Practice by topic", "مضمون کے لحاظ سے مشق"),
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.padding(top = 6.dp)
            )
            vm.topics.forEach { t ->
                val n = vm.mcqCount(t.id)
                if (n > 0) {
                    val g = groupOf(t.id)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onRun("practice", t.id) },
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                        )
                    ) {
                        Row(Modifier.padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(g.emoji, style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(vm.title(t), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                                Text(
                                    vm.t("$n MCQs", "$n ایم سی کیوز"),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            }
                            TextButton(onClick = { onRun("browse", t.id) }) {
                                Text(vm.t("Read", "پڑھیں"))
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}

// ---------- Practice / browse run ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun McqRunScreen(vm: AppVM, mode: String, topic: Int, onBack: () -> Unit) {
    val list = remember(mode, topic) {
        val base = when (mode) {
            "wrong" -> vm.mcqs.filter { vm.mcqWrong.contains(it.id) }
            "saved" -> vm.mcqs.filter { vm.mcqSaved.contains(it.id) }
            else -> vm.mcqs.filter { topic == 0 || it.topic == topic }
        }
        if (mode == "browse" || mode == "saved") base else base.shuffled()
    }
    val title = when (mode) {
        "wrong" -> vm.t("Revise wrong answers", "غلط جوابات")
        "saved" -> vm.t("Saved MCQs", "محفوظ ایم سی کیوز")
        else -> {
            val tp = vm.topic(topic)
            if (tp != null) vm.title(tp) else vm.t("All topics", "تمام مضامین")
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title, maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
    ) { pad ->
        Column(Modifier.fillMaxSize().padding(pad)) {
            if (list.isEmpty()) {
                Text(
                    vm.t("No MCQs here yet.", "یہاں ابھی کوئی ایم سی کیو نہیں۔"),
                    modifier = Modifier.padding(16.dp)
                )
            } else if (mode == "browse" || mode == "saved") {
                McqBrowse(vm, list)
            } else {
                McqPractice(vm, list, onBack)
            }
        }
    }
}

@Composable
private fun McqBrowse(vm: AppVM, list: List<Mcq>) {
    val ls = letters(vm)
    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                vm.t("${list.size} MCQs – correct answers are highlighted", "${list.size} ایم سی کیوز – درست جواب نمایاں ہیں"),
                style = MaterialTheme.typography.bodySmall
            )
        }
        items(list) { m ->
            val tp = vm.topic(m.topic)
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (tp != null) vm.title(tp) else "",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { vm.toggleMcqSaved(m.id) }) {
                            Icon(
                                Icons.Filled.Favorite,
                                contentDescription = null,
                                tint = if (vm.mcqSaved.contains(m.id)) MaterialTheme.colorScheme.error
                                else MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                    Text(m.question(vm), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                    m.options(vm).forEachIndexed { i, o ->
                        val right = i == m.ans
                        Text(
                            (if (right) "✔ " else "") + ls.getOrElse(i) { "" } + ". " + o,
                            color = if (right) GoodColor else MaterialTheme.colorScheme.onSurface,
                            fontWeight = if (right) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                    Text(
                        m.explanation(vm),
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }
        }
        item { Spacer(Modifier.height(16.dp)) }
    }
}

@Composable
private fun McqPractice(vm: AppVM, list: List<Mcq>, onBack: () -> Unit) {
    var idx by remember { mutableIntStateOf(0) }
    var picked by remember { mutableIntStateOf(-1) }
    var score by remember { mutableIntStateOf(0) }
    var finished by remember { mutableStateOf(false) }
    val ls = letters(vm)

    if (finished) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically)
        ) {
            Text("🎉", style = MaterialTheme.typography.displayMedium)
            Text(
                vm.t("You got $score of ${list.size} right", "آپ نے ${list.size} میں سے $score درست کیے"),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                vm.t(
                    "Wrong answers are saved in your revise list.",
                    "غلط جوابات آپ کی ریویژن فہرست میں محفوظ ہو گئے ہیں۔"
                ),
                style = MaterialTheme.typography.bodyMedium
            )
            Button(onClick = { idx = 0; picked = -1; score = 0; finished = false }) {
                Text(vm.t("Try again", "دوبارہ کوشش کریں"))
            }
            OutlinedButton(onClick = onBack) { Text(vm.t("Back", "واپس")) }
        }
        return
    }

    val q = list[idx]
    val tp = vm.topic(q.topic)
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        LinearProgressIndicator(
            progress = { (idx + 1) / list.size.toFloat() },
            modifier = Modifier.fillMaxWidth()
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    vm.t("Question ${idx + 1} of ${list.size}", "سوال ${idx + 1} از ${list.size}"),
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
                if (tp != null) {
                    Text(vm.title(tp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                }
            }
            IconButton(onClick = { vm.toggleMcqSaved(q.id) }) {
                Icon(
                    Icons.Filled.Favorite,
                    contentDescription = null,
                    tint = if (vm.mcqSaved.contains(q.id)) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.outline
                )
            }
        }

        Text(q.question(vm), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)

        q.options(vm).forEachIndexed { i, o ->
            val container = when {
                picked == -1 -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                i == q.ans -> GoodColor.copy(alpha = 0.28f)
                i == picked -> BadColor.copy(alpha = 0.28f)
                else -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
            }
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable(enabled = picked == -1) {
                        picked = i
                        val ok = i == q.ans
                        if (ok) score += 1
                        vm.recordMcq(q.id, ok)
                    },
                colors = CardDefaults.cardColors(containerColor = container)
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        ls.getOrElse(i) { "" } + ".",
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.width(36.dp)
                    )
                    Text(o, modifier = Modifier.weight(1f))
                    if (picked != -1 && i == q.ans) Text("✔", color = GoodColor, fontWeight = FontWeight.Bold)
                    if (picked != -1 && i == picked && i != q.ans) Text("✘", color = BadColor, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (picked != -1) {
            Text(
                if (picked == q.ans) vm.t("Correct!", "درست!") else vm.t("Not quite.", "درست نہیں۔"),
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = if (picked == q.ans) GoodColor else BadColor
            )
            Text(q.explanation(vm), style = MaterialTheme.typography.bodyMedium)
            Button(
                onClick = {
                    if (idx + 1 < list.size) {
                        idx += 1
                        picked = -1
                    } else {
                        finished = true
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    if (idx + 1 < list.size) vm.t("Next question", "اگلا سوال")
                    else vm.t("Finish", "ختم کریں")
                )
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}
