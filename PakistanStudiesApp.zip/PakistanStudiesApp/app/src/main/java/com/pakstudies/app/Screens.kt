package com.pakstudies.app

import android.content.Intent
import android.speech.tts.TextToSpeech
import android.widget.Toast
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import java.util.Locale

// ---------- Small shared pieces ----------

@Composable
private fun RingProgress(
    fraction: Float,
    label: String,
    diameter: Dp,
    color: Color,
    track: Color,
    big: Boolean = false
) {
    val f by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(600), label = "ring")
    Box(Modifier.size(diameter), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = diameter.toPx() * 0.11f
            val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
            val tl = Offset(stroke / 2f, stroke / 2f)
            drawArc(track, 0f, 360f, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            if (f > 0.001f) {
                drawArc(color, -90f, 360f * f, false, tl, arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            }
        }
        Text(
            label,
            style = if (big) MaterialTheme.typography.displaySmall else MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun TopicCard(vm: AppVM, t: Topic, onOpen: (Int) -> Unit) {
    val g = groupOf(t.id)
    val revised = vm.revisedCount(t)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.97f else 1f, label = "press")

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            }
            .clickable(interactionSource = src, indication = LocalIndication.current) { onOpen(t.id) },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(g.color.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center
            ) {
                Text(g.emoji, style = MaterialTheme.typography.titleLarge)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(vm.title(t), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(
                    "${t.id} • " + vm.category(t),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.secondary
                )
                Spacer(Modifier.height(6.dp))
                LinearProgressIndicator(
                    progress = { if (t.subs.isEmpty()) 0f else revised / t.subs.size.toFloat() },
                    color = g.color,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            if (vm.hard.contains(t.id)) {
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Filled.Star, contentDescription = null, tint = Color(0xFFF9A825))
            }
            if (vm.done.contains(t.id)) {
                Spacer(Modifier.width(8.dp))
                Icon(Icons.Filled.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            }
            if (vm.bookmarks.contains(t.id)) {
                Spacer(Modifier.width(4.dp))
                Icon(Icons.Filled.Favorite, contentDescription = null, tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

@Composable
private fun GroupHeader(vm: AppVM, g: Group, count: Int) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 10.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(g.emoji, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.width(8.dp))
        Text(
            vm.groupName(g),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
        Text("$count", style = MaterialTheme.typography.labelMedium, color = g.color)
    }
}

// ---------- Home ----------

@Composable
fun HomeScreen(vm: AppVM, onOpen: (Int) -> Unit) {
    val today = vm.topicOfTheDay()
    val last = vm.topic(vm.lastTopic)
    val (pointTopic, pointText) = vm.pointOfTheDay()
    val doneCount = vm.done.size
    val total = vm.topics.size
    val revised = vm.revisedSubs
    val totalSubs = vm.totalSubs
    val enDays = listOf("M", "T", "W", "T", "F", "S", "S")
    val urDays = listOf("پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ", "اتوار")
    val primary = MaterialTheme.colorScheme.primary
    val track = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.15f)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    vm.t("Pakistan Studies", "مطالعۂ پاکستان"),
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    vm.t("Smart offline learning", "آف لائن سمارٹ لرننگ"),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            OutlinedButton(onClick = { vm.toggleLang() }) {
                Text(if (vm.isUrdu) "English" else "اردو")
            }
        }

        // Progress rings
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(vm.t("Your progress", "آپ کی پیش رفت"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        RingProgress(doneCount / total.toFloat(), "$doneCount/$total", 104.dp, primary, track)
                        Spacer(Modifier.height(6.dp))
                        Text(vm.t("Topics done", "مکمل مضامین"), style = MaterialTheme.typography.bodySmall)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val frac = if (totalSubs == 0) 0f else revised / totalSubs.toFloat()
                        RingProgress(frac, "${(frac * 100).toInt()}%", 104.dp, primary, track)
                        Spacer(Modifier.height(6.dp))
                        Text(vm.t("Points revised", "دہرائے گئے نکات"), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        // 7-day streak
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    vm.t("Study streak: ${vm.streak} day(s)", "مسلسل دن: ${vm.streak}"),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    vm.last7().forEach { (date, studied) ->
                        val idx = date.dayOfWeek.value - 1
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                if (vm.isUrdu) urDays[idx] else enDays[idx],
                                style = MaterialTheme.typography.labelSmall
                            )
                            Spacer(Modifier.height(4.dp))
                            Box(
                                Modifier
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(
                                        if (studied) MaterialTheme.colorScheme.primary
                                        else MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                if (studied) {
                                    Icon(
                                        Icons.Filled.Check,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Point of the day
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onOpen(pointTopic.id) },
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)
        ) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("💡 " + vm.t("Point of the day", "آج کا نکتہ"), style = MaterialTheme.typography.titleSmall)
                Text(pointText, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                Text(vm.title(pointTopic), style = MaterialTheme.typography.bodySmall)
            }
        }

        if (last != null) {
            Text(vm.t("Continue where you left off", "جہاں چھوڑا تھا وہیں سے جاری رکھیں"), style = MaterialTheme.typography.titleSmall)
            TopicCard(vm, last, onOpen)
        }

        Text(vm.t("Topic of the day", "آج کا مضمون"), style = MaterialTheme.typography.titleSmall)
        TopicCard(vm, today, onOpen)
    }
}

// ---------- Topics list (grouped) ----------

@Composable
fun TopicsScreen(vm: AppVM, onOpen: (Int) -> Unit) {
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf(0) } // 0 all, 1 pending, 2 completed, 3 saved, 4 revision
    val q = query.trim().lowercase()

    val list = vm.topics.filter { t ->
        val matches = q.isEmpty() ||
            t.titleEn.lowercase().contains(q) || t.titleUr.contains(q) ||
            t.catEn.lowercase().contains(q) || t.catUr.contains(q) ||
            t.subs.any { it.lowercase().contains(q) } || t.subsUr.any { it.contains(q) }
        val ok = when (filter) {
            1 -> !vm.done.contains(t.id)
            2 -> vm.done.contains(t.id)
            3 -> vm.bookmarks.contains(t.id)
            4 -> vm.hard.contains(t.id)
            else -> true
        }
        matches && ok
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text(vm.t("Search topics or points", "مضامین یا نکات تلاش کریں")) },
            trailingIcon = {
                if (query.isNotEmpty()) {
                    IconButton(onClick = { query = "" }) { Icon(Icons.Filled.Close, contentDescription = null) }
                }
            }
        )
        Row(
            Modifier
                .horizontalScroll(rememberScrollState())
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val labels = listOf(
                vm.t("All", "تمام"), vm.t("Pending", "باقی"),
                vm.t("Completed", "مکمل"), vm.t("Saved", "محفوظ"),
                vm.t("Revision", "ریویژن")
            )
            labels.forEachIndexed { i, l ->
                FilterChip(selected = filter == i, onClick = { filter = i }, label = { Text(l) })
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxSize()) {
            if (list.isEmpty()) {
                item { Text(vm.t("No topics found.", "کوئی مضمون نہیں ملا۔")) }
            }
            GROUPS.forEach { g ->
                val inGroup = list.filter { it.id in g.ids }
                if (inGroup.isNotEmpty()) {
                    item(key = "h${g.key}") { GroupHeader(vm, g, inGroup.size) }
                    items(inGroup, key = { it.id }) { t -> TopicCard(vm, t, onOpen) }
                }
            }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }
}

// ---------- Saved, revision list & notes ----------

@Composable
fun SavedScreen(vm: AppVM, onOpen: (Int) -> Unit) {
    val saved = vm.topics.filter { vm.bookmarks.contains(it.id) }
    val revision = vm.topics.filter { vm.hard.contains(it.id) }
    val withNotes = vm.topics.filter { vm.notes.containsKey(it.id) }

    LazyColumn(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text("⭐ " + vm.t("Revision list", "ریویژن لسٹ"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (revision.isEmpty()) {
            item {
                Text(vm.t("Mark difficult topics with the star button inside a topic.", "مشکل مضامین کو مضمون کے اندر ستارے کے بٹن سے نشان زد کریں۔"))
            }
        }
        items(revision, key = { "r${it.id}" }) { t -> TopicCard(vm, t, onOpen) }

        item {
            Spacer(Modifier.height(8.dp))
            Text("❤ " + vm.t("Saved topics", "محفوظ مضامین"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (saved.isEmpty()) {
            item {
                Text(vm.t("Tap the heart inside a topic to save it here.", "کسی مضمون کے اندر دل کے نشان پر ٹیپ کریں، وہ یہاں محفوظ ہو جائے گا۔"))
            }
        }
        items(saved, key = { "s${it.id}" }) { t -> TopicCard(vm, t, onOpen) }

        item {
            Spacer(Modifier.height(8.dp))
            Text("📝 " + vm.t("My notes", "میرے نوٹس"), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        if (withNotes.isEmpty()) {
            item { Text(vm.t("Notes you write inside topics appear here.", "مضامین کے اندر لکھے گئے نوٹس یہاں نظر آئیں گے۔")) }
        }
        items(withNotes, key = { "n${it.id}" }) { t ->
            Card(Modifier.fillMaxWidth().clickable { onOpen(t.id) }) {
                Column(Modifier.padding(14.dp)) {
                    Text(vm.title(t), fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(4.dp))
                    Text(vm.notes[t.id] ?: "", maxLines = 3, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

// ---------- Detail ----------

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(vm: AppVM, id: Int, onBack: () -> Unit, onOpen: (Int) -> Unit) {
    val t = vm.topic(id) ?: vm.topics.first()
    val g = groupOf(t.id)
    val ctx = LocalContext.current
    var speaking by remember { mutableStateOf(false) }
    var ready by remember { mutableStateOf(false) }
    val tts = remember { arrayOfNulls<TextToSpeech>(1) }

    DisposableEffect(Unit) {
        vm.setLast(id)
        tts[0] = TextToSpeech(ctx) { status -> ready = status == TextToSpeech.SUCCESS }
        onDispose {
            tts[0]?.stop()
            tts[0]?.shutdown()
        }
    }

    val subs = vm.subtitles(t)
    var note by remember(id) { mutableStateOf(vm.notes[id] ?: "") }

    fun readAloud() {
        val engine = tts[0]
        if (!ready || engine == null) {
            Toast.makeText(ctx, vm.t("Text-to-speech is not ready", "ٹیکسٹ ٹو اسپیچ تیار نہیں"), Toast.LENGTH_SHORT).show()
            return
        }
        if (speaking) {
            engine.stop(); speaking = false; return
        }
        val locale = if (vm.isUrdu) Locale("ur") else Locale.ENGLISH
        val r = engine.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(
                ctx,
                vm.t("This voice is not installed on your phone", "یہ آواز آپ کے فون میں انسٹال نہیں ہے"),
                Toast.LENGTH_LONG
            ).show()
            return
        }
        val text = vm.title(t) + ". " + vm.category(t) + ". " + subs.joinToString(". ")
        engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "topic$id")
        speaking = true
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("${t.id}", color = MaterialTheme.colorScheme.primary) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null) }
                },
                actions = {
                    IconButton(onClick = { readAloud() }) {
                        Icon(if (speaking) Icons.Filled.Close else Icons.Filled.PlayArrow, contentDescription = null)
                    }
                    IconButton(onClick = {
                        val text = vm.title(t) + "\n" + vm.category(t) + "\n\n" +
                            subs.mapIndexed { i, s -> "${i + 1}. $s" }.joinToString("\n")
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        ctx.startActivity(Intent.createChooser(send, null))
                    }) { Icon(Icons.Filled.Share, contentDescription = null) }
                    IconButton(onClick = { vm.toggleHard(id) }) {
                        Icon(
                            Icons.Filled.Star,
                            contentDescription = null,
                            tint = if (vm.hard.contains(id)) Color(0xFFF9A825) else MaterialTheme.colorScheme.outline
                        )
                    }
                    IconButton(onClick = { vm.toggleBookmark(id) }) {
                        Icon(
                            Icons.Filled.Favorite,
                            contentDescription = null,
                            tint = if (vm.bookmarks.contains(id)) MaterialTheme.colorScheme.error
                            else MaterialTheme.colorScheme.outline
                        )
                    }
                }
            )
        }
    ) { pad ->
        LazyColumn(
            Modifier.fillMaxSize().padding(pad).padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                Text(vm.title(t), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(g.emoji + " " + vm.category(t), color = MaterialTheme.colorScheme.secondary)
                Spacer(Modifier.height(6.dp))
                val rev = vm.revisedCount(t)
                Text(vm.t("Revised $rev of ${subs.size} points", "$rev / ${subs.size} نکات دہرائے گئے"), style = MaterialTheme.typography.bodySmall)
                LinearProgressIndicator(
                    progress = { if (subs.isEmpty()) 0f else rev / subs.size.toFloat() },
                    color = g.color,
                    modifier = Modifier.fillMaxWidth()
                )
            }
            item { HorizontalDivider() }
            itemsIndexed(subs) { i, s ->
                Row(
                    Modifier.fillMaxWidth().clickable { vm.toggleChecked(id, i) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(checked = vm.isChecked(id, i), onCheckedChange = { vm.toggleChecked(id, i) })
                    Text(s, style = MaterialTheme.typography.bodyLarge, modifier = Modifier.weight(1f))
                }
            }
            item { HorizontalDivider() }
            item {
                Button(onClick = { vm.toggleDone(id) }, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        if (vm.done.contains(id)) vm.t("Completed – tap to undo", "مکمل – واپس کرنے کے لیے ٹیپ کریں")
                        else vm.t("Mark topic as completed", "مضمون مکمل کے طور پر نشان زد کریں")
                    )
                }
            }
            item {
                OutlinedButton(onClick = { vm.toggleHard(id) }, modifier = Modifier.fillMaxWidth()) {
                    Text(
                        if (vm.hard.contains(id)) "★ " + vm.t("In revision list – tap to remove", "ریویژن لسٹ میں ہے – ہٹانے کے لیے ٹیپ کریں")
                        else "☆ " + vm.t("Add to revision list (difficult)", "ریویژن لسٹ میں شامل کریں (مشکل)")
                    )
                }
            }
            item {
                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it; vm.saveNote(id, it) },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 4,
                    label = { Text(vm.t("My notes (saved automatically)", "میرے نوٹس (خود بخود محفوظ)")) }
                )
            }
            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton(enabled = id > 1, onClick = { onOpen(id - 1) }) { Text(vm.t("← Previous", "← پچھلا")) }
                    TextButton(enabled = id < vm.topics.size, onClick = { onOpen(id + 1) }) { Text(vm.t("Next →", "اگلا →")) }
                }
                Spacer(Modifier.height(16.dp))
            }
        }
    }
}

// ---------- Study timer ----------

@Composable
fun TimerScreen(vm: AppVM) {
    val total = vm.timerTotal()
    val remaining = vm.timerSecs
    val mm = remaining / 60
    val ss = remaining % 60
    val label = String.format(Locale.US, "%02d:%02d", mm, ss)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Text(
            vm.t("Study timer", "اسٹڈی ٹائمر"),
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            FilterChip(
                selected = vm.timerFocus,
                onClick = { vm.timerSetMode(true) },
                label = { Text(vm.t("Focus 25 min", "فوکس 25 منٹ")) }
            )
            FilterChip(
                selected = !vm.timerFocus,
                onClick = { vm.timerSetMode(false) },
                label = { Text(vm.t("Break 5 min", "وقفہ 5 منٹ")) }
            )
        }
        RingProgress(
            fraction = remaining / total.toFloat(),
            label = label,
            diameter = 240.dp,
            color = if (vm.timerFocus) MaterialTheme.colorScheme.primary else Color(0xFFE65100),
            track = MaterialTheme.colorScheme.surfaceVariant,
            big = true
        )
        Text(
            if (vm.timerFocus) vm.t("Time to focus 📖", "پڑھنے کا وقت 📖")
            else vm.t("Take a short break ☕", "تھوڑا وقفہ کریں ☕"),
            style = MaterialTheme.typography.titleMedium
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { vm.timerToggle() }) {
                Text(if (vm.timerRunning) vm.t("Pause", "روکیں") else vm.t("Start", "شروع کریں"))
            }
            OutlinedButton(onClick = { vm.timerReset() }) { Text(vm.t("Reset", "ری سیٹ")) }
        }
        Text(
            vm.t(
                "The timer keeps running while you switch between screens, but stops if you close the app.",
                "ٹائمر اسکرینیں بدلنے پر چلتا رہتا ہے، لیکن ایپ بند کرنے پر رک جاتا ہے۔"
            ),
            style = MaterialTheme.typography.bodySmall
        )
    }
}

// ---------- Settings ----------

@Composable
fun SettingsScreen(vm: AppVM) {
    var confirmReset by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text(vm.t("Settings", "ترتیبات"), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)

        Text(vm.t("Language", "زبان"), style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = !vm.isUrdu, onClick = { vm.updateLang("en") }, label = { Text("English") })
            FilterChip(selected = vm.isUrdu, onClick = { vm.updateLang("ur") }, label = { Text("اردو") })
        }

        Text(vm.t("Theme", "تھیم"), style = MaterialTheme.typography.titleSmall)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = vm.theme == 0, onClick = { vm.updateTheme(0) }, label = { Text(vm.t("System", "سسٹم")) })
            FilterChip(selected = vm.theme == 1, onClick = { vm.updateTheme(1) }, label = { Text(vm.t("Light", "روشن")) })
            FilterChip(selected = vm.theme == 2, onClick = { vm.updateTheme(2) }, label = { Text(vm.t("Dark", "گہرا")) })
        }

        Text(vm.t("Text size", "تحریر کا سائز"), style = MaterialTheme.typography.titleSmall)
        Slider(value = vm.fontScale, onValueChange = { vm.setFont(it) }, valueRange = 0.8f..1.5f)
        Text(vm.t("Preview: The quick brown fox", "نمونہ: پاکستان زندہ باد"))

        HorizontalDivider()

        OutlinedButton(onClick = { confirmReset = true }) {
            Text(vm.t("Reset progress, saved topics and revision ticks", "پیش رفت، محفوظ مضامین اور نشانات ری سیٹ کریں"))
        }
        if (confirmReset) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { vm.resetProgress(); confirmReset = false }) { Text(vm.t("Yes, reset", "ہاں، ری سیٹ")) }
                TextButton(onClick = { confirmReset = false }) { Text(vm.t("Cancel", "منسوخ")) }
            }
            Text(vm.t("Your written notes are kept.", "آپ کے لکھے ہوئے نوٹس محفوظ رہیں گے۔"), style = MaterialTheme.typography.bodySmall)
        }

        Text(
            vm.t("Works fully offline. No internet permission, no ads, no account.",
                "مکمل آف لائن۔ انٹرنیٹ کی اجازت، اشتہارات یا اکاؤنٹ کی ضرورت نہیں۔"),
            style = MaterialTheme.typography.bodySmall
        )
    }
}
