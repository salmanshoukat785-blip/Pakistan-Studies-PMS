package com.pakstudies.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection

private val Light = lightColorScheme(
    primary = Color(0xFF0B6B3A),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFCDEBD7),
    onPrimaryContainer = Color(0xFF00210F),
    secondary = Color(0xFF4F6354),
    secondaryContainer = Color(0xFFD2E8D6),
    background = Color(0xFFF8FBF7),
    surface = Color(0xFFF8FBF7),
    surfaceVariant = Color(0xFFDDE5DB)
)

private val Dark = darkColorScheme(
    primary = Color(0xFF7DDA9B),
    onPrimary = Color(0xFF00391C),
    primaryContainer = Color(0xFF0B5230),
    onPrimaryContainer = Color(0xFFCDEBD7),
    secondary = Color(0xFFB6CCBA),
    secondaryContainer = Color(0xFF384B3E),
    background = Color(0xFF101411),
    surface = Color(0xFF101411),
    surfaceVariant = Color(0xFF404941)
)

@Composable
fun AppTheme(vm: AppVM, content: @Composable () -> Unit) {
    val dark = when (vm.theme) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val density = LocalDensity.current
    CompositionLocalProvider(
        LocalLayoutDirection provides if (vm.isUrdu) LayoutDirection.Rtl else LayoutDirection.Ltr,
        LocalDensity provides Density(density.density, density.fontScale * vm.fontScale)
    ) {
        MaterialTheme(colorScheme = if (dark) Dark else Light, content = content)
    }
}
